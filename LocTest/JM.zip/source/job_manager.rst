Job Manager
===========

.. automodule:: job_manager
   :members:
   :special-members: __init__
   :private-members:
