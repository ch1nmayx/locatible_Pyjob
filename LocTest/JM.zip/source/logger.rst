Logger
======

.. automodule:: logger
   :members:
   :special-members: __init__
   :private-members:
